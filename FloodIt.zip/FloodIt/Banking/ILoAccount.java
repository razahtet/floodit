
// Represents a List of Accounts
interface ILoAccount {

}

