
// Represents a savings account
class Savings extends Account {

  double interest; // The interest rate

  Savings(int accountNum, int balance, String name, double interest) {
    super(accountNum, balance, name);
    this.interest = interest;
  }
}
